﻿using System;
namespace program
{
    class exerc1
    {
        static void Main(string[] args)
        {
            for (int i = 12; i < 250; i++)
            {
                Console.WriteLine(i);
                i = i + 1;
            }
        }
    }
}