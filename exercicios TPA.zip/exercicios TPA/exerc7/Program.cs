﻿
using System;
    class atividade7
{
    static void Main(string[] args)
    {
        for (int i = 1; i <= 100; i++)
        {
            Console.WriteLine(i);
            if (i == 10)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 20)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 30)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 40)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 50)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 60)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 70)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 80)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 90)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
            if (i == 100)
            {
                Console.WriteLine("MÚLTIPLO DE 10");
            }
        }
    }
}
}